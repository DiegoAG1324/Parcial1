// Crear un nuevo elemento de párrafo
var nuevoParrafo = document.createElement('p');

// Agregar texto al párrafo
nuevoParrafo.textContent = '¡Hola, soy un nuevo párrafo!';

// Obtener la referencia al cuerpo del documento
var cuerpoDocumento = document.body;

// Agregar el nuevo párrafo como hijo al final del cuerpo
cuerpoDocumento.appendChild(nuevoParrafo);


document.addEventListener("DOMContentLoaded", function() {
    // Obtén todos los elementos con la clase "orange-box"
    var orangeBoxes = document.querySelectorAll('.orange-box');

    // Agrega un evento de mouseover a cada cuadro naranja
    orangeBoxes.forEach(function(box) {
        box.addEventListener('mouseover', function() {
            // Agrega una clase al cuadro al pasar el mouse para aplicar la animación
            box.classList.add('hovered');
            // Llama a la función para agregar información sobre Pokémon
            addPokemonInfo(box);
        });

        // Agrega un evento de mouseout para revertir la animación al retirar el mouse
        box.addEventListener('mouseout', function() {
            // Elimina la clase al retirar el mouse para revertir la animación
            box.classList.remove('hovered');
        });
    });
});





